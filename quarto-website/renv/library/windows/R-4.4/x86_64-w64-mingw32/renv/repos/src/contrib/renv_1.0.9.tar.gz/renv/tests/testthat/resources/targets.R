tar_option_set(packages = c("A", "B"))
tar_option_set(packages = oops)
